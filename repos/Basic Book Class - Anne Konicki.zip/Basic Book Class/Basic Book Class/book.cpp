#include "book.h"

Book::Book(const string& name, Type type, int pages, float ounces) {

	bName = name;
	bType = type;
	bPages = pages;
	bOunces = ounces;
}